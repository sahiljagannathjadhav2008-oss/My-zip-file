// ===== Element References =====
const totalUnit = document.getElementById("totalUnit");
const totalPrice = document.getElementById("totalPrice");
const perUnit = document.getElementById("perUnit");
const lockToggle = document.getElementById("lockToggle");
const roomTable = document.getElementById("roomTable");
const remaining = document.getElementById("remaining");

// ===== Month & Year Populate =====
const monthSel = document.getElementById("month");
const yearSel = document.getElementById("year");

const months = [
  "January","February","March","April","May","June",
  "July","August","September","October","November","December"
];
months.forEach(m => {
  const opt = document.createElement("option");
  opt.textContent = m;
  monthSel.appendChild(opt);
});
for (let y = 2024; y <= 2040; y++) {
  const opt = document.createElement("option");
  opt.textContent = y;
  yearSel.appendChild(opt);
}

// ===== Calculate Per Unit =====
function updatePerUnit() {
  if (totalUnit.value && totalPrice.value) {
    perUnit.value = (parseFloat(totalPrice.value) / parseFloat(totalUnit.value)).toFixed(3);
    updateRoomCalculations();
  }
}

// ===== Main Calculations =====
function updateRoomCalculations() {
  const rows = roomTable.querySelectorAll("tbody tr");
  let totalUsedUnits = 0;
  let totalUsedAmount = 0;

  rows.forEach(row => {
    const curr = parseFloat(row.querySelector(".current").value) || 0;
    const prev = parseFloat(row.querySelector(".previous").value) || 0;
    const totalU = curr - prev;
    const totalA = totalU * (parseFloat(perUnit.value) || 0);

    row.querySelector(".totalUnit").value = totalU >= 0 ? totalU.toFixed(2) : "0.00";
    row.querySelector(".totalAmount").value = totalA >= 0 ? totalA.toFixed(2) : "0.00";

    totalUsedUnits += totalU;
    totalUsedAmount += totalA;
  });

  const remainingUnits = (parseFloat(totalUnit.value || 0) - totalUsedUnits).toFixed(2);
  const remainingAmount = (parseFloat(totalPrice.value || 0) - totalUsedAmount).toFixed(2);
  remaining.value = `युनिट: ${remainingUnits} | ₹${remainingAmount}`;
}

// ===== Lock / Unlock =====
function setLockedState(locked) {
  document.querySelectorAll("input").forEach(inp => {
    if (inp.id !== "lockToggle") inp.disabled = locked;
  });
}

// ===== Save Data Locally =====
function saveData() {
  const data = {
    totalUnit: totalUnit.value,
    totalPrice: totalPrice.value,
    perUnit: perUnit.value,
    remaining: remaining.value,
    month: monthSel.value,
    year: yearSel.value,
    rooms: []
  };
  roomTable.querySelectorAll("tbody tr").forEach(row => {
    data.rooms.push({
      name: row.querySelector(".roomName").textContent,
      current: row.querySelector(".current").value,
      previous: row.querySelector(".previous").value,
      totalUnit: row.querySelector(".totalUnit").value,
      totalAmount: row.querySelector(".totalAmount").value
    });
  });
  localStorage.setItem("billData", JSON.stringify(data));
  alert("✅ डेटा सेव्ह झाला आहे!");
}

// ===== Load Saved Data =====
function loadData() {
  const saved = localStorage.getItem("billData");
  if (!saved) return;
  const data = JSON.parse(saved);

  totalUnit.value = data.totalUnit;
  totalPrice.value = data.totalPrice;
  perUnit.value = data.perUnit;
  remaining.value = data.remaining;
  monthSel.value = data.month;
  yearSel.value = data.year;

  const rows = roomTable.querySelectorAll("tbody tr");
  data.rooms.forEach((r, i) => {
    if (rows[i]) {
      rows[i].querySelector(".roomName").textContent = r.name;
      rows[i].querySelector(".current").value = r.current;
      rows[i].querySelector(".previous").value = r.previous;
      rows[i].querySelector(".totalUnit").value = r.totalUnit;
      rows[i].querySelector(".totalAmount").value = r.totalAmount;
    }
  });
  updateRoomCalculations();
}

// ===== Next Month Reset =====
function clearForNextMonth() {
  roomTable.querySelectorAll("tbody tr").forEach(row => {
    row.querySelector(".previous").value = row.querySelector(".current").value;
    row.querySelector(".current").value = "";
    row.querySelector(".totalUnit").value = "";
    row.querySelector(".totalAmount").value = "";
  });
  remaining.value = "";
  lockToggle.checked = false;
  setLockedState(false);
  alert("📅 नवीन महिन्यासाठी तयार!");
}

// ===== PDF Download (Full App) =====
function downloadPDF() {
  const element = document.getElementById("app");
  const opt = {
    margin: 0.3,
    filename: `Bill_${monthSel.value}_${yearSel.value}.pdf`,
    image: { type: "jpeg", quality: 1 },
    html2canvas: { scale: 3, useCORS: true, scrollY: 0, backgroundColor: "#ffffff" },
    jsPDF: { unit: "in", format: "a4", orientation: "portrait" }
  };
  html2pdf().set(opt).from(element).save();
}

// ===== Event Listeners =====
totalUnit.addEventListener("input", updatePerUnit);
totalPrice.addEventListener("input", updatePerUnit);
roomTable.addEventListener("input", updateRoomCalculations);
lockToggle.addEventListener("change", () => setLockedState(lockToggle.checked));
document.getElementById("saveData").addEventListener("click", saveData);
document.getElementById("nextMonth").addEventListener("click", clearForNextMonth);
document.getElementById("downloadPDF").addEventListener("click", downloadPDF);
window.addEventListener("DOMContentLoaded", loadData);
